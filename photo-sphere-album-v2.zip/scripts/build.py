#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
photo-sphere-album — 交互式 3D 照片星球生成器
============================================
把本地照片文件夹生成一个自包含、可离线打开的网页：
  · 照片以斐波那契球面均匀分布，开场从四散飞入聚成球，随后持续自转；
  · 自转较快，且每次构建都打乱照片↔球面位置的对应关系，并用 acos 分布
    消除精确两极点 + 缓慢进动，避免某些照片长期待在最上/最下被忽略；
  · 鼠标光标移到某张照片上，它平滑「飞到屏幕正中央」放大呈现，其余变暗、
    球体暂停；光标移开中央区域就飞回球面、恢复自转；
  · （可选）把一首本地音频（flac/mp3/...）以 base64 直接内嵌进 HTML，
    页面首次点击/触摸即自动循环播放，无需外部 mp3 文件。

依赖：Pillow（缩略图生成 + EXIF 转正）。无其它外部库、无 CDN、无网络请求。

用法：
    python build.py <源照片目录> [--out 输出目录] [--music 歌曲.flac]
                   [--title 标题] [--speed 1.0] [--limit N] [--force]
"""

import os
import re
import sys
import json
import base64
import math
import random
import argparse
import shutil
from PIL import Image, ImageOps

EXT = ('.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp',
       '.tif', '.tiff', '.heic', '.heif')
MIME = {
    '.flac': 'audio/flac', '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4',
    '.aac': 'audio/aac', '.wav': 'audio/wav', '.ogg': 'audio/ogg',
    '.oga': 'audio/ogg',
}


# --------------------------------------------------------------------------
# 工具函数
# --------------------------------------------------------------------------
def get_capture_date(path):
    """优先读取 EXIF DateTimeOriginal / DateTime，返回 'YYYY-MM-DD HH:MM' 或 None。"""
    try:
        with Image.open(path) as im:
            exif = im.getexif()
            for tag in (36867, 306):  # DateTimeOriginal, DateTime
                v = exif.get(tag)
                if v:
                    v = str(v).replace('\x00', '').strip()
                    date = v[:10].replace(':', '-')
                    time = v[11:16] if len(v) >= 16 else ''
                    return (date + (' ' + time if time else '')).strip()
    except Exception:
        pass
    return None


def safe_name(name, i):
    base, _ = os.path.splitext(name)
    s = re.sub(r'[^\w\u4e00-\u9fff\-]+', '_', base)
    s = s.strip('_')[:40] or 'photo'
    return f"{i:03d}_{s}.jpg"


def make_thumb(src, dst, size=720, force=False):
    """生成最长边 <= size 的 JPEG 缩略图（按 EXIF 方向转正），已存在则跳过（幂等）。"""
    if os.path.exists(dst) and not force:
        return
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    with Image.open(src) as im:
        im = ImageOps.exif_transpose(im)
        im = im.convert('RGB')
        im.thumbnail((size, size), Image.LANCZOS)
        im.save(dst, 'JPEG', quality=82)


def sphere_positions(n):
    """斐波那契球面分布；用 acos(1 - 2*(i+0.5)/n) 避免精确两极点。"""
    pts = []
    gold = math.pi * (1 + 5 ** 0.5)
    for i in range(n):
        phi = math.acos(1 - 2 * (i + 0.5) / n)      # 0..pi（不会正好 0 或 pi）
        theta = gold * i
        x = math.sin(phi) * math.cos(theta)
        y = math.cos(phi)
        z = math.sin(phi) * math.sin(theta)
        pts.append((x, y, z))
    return pts


# --------------------------------------------------------------------------
# HTML 模板（内联 CSS/JS，零外部依赖）
# --------------------------------------------------------------------------
TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>__TITLE__</title>
<style>
  * { box-sizing: border-box; }
  html, body { margin: 0; height: 100%; overflow: hidden;
    background: radial-gradient(ellipse at 50% 40%, #0b1c3a 0%, #050a1c 55%, #01030a 100%);
    font-family: "PingFang SC","Microsoft YaHei",system-ui,sans-serif; color: #eaf2ff; }
  #stars { position: fixed; inset: 0; z-index: 0; }
  #stage { position: fixed; inset: 0; z-index: 1; }
  #sphere { position: absolute; inset: 0; }
  .photo { position: absolute; left: 0; top: 0; border-radius: 7px; overflow: hidden;
    box-shadow: 0 4px 18px rgba(0,0,0,.55); cursor: pointer; will-change: transform, opacity;
    background: #10203f; transition: box-shadow .25s, border-color .25s; border: 2px solid transparent; }
  .photo img { width: 100%; height: 100%; object-fit: cover; display: block; pointer-events: none;
    -webkit-user-drag: none; user-select: none; }
  .photo.broken { background: #1a2540; }
  .photo.broken::after { content: "图片加载失败"; position: absolute; inset: 0;
    display: flex; align-items: center; justify-content: center; font-size: 12px; color: #8fa6cf; }
  .photo.active { box-shadow: 0 0 45px rgba(120,180,255,.9); border-color: rgba(255,255,255,.85); z-index: 999; }
  #caption { position: fixed; left: 50%; bottom: 26px; transform: translateX(-50%);
    z-index: 5; text-align: center; padding: 10px 18px; border-radius: 12px;
    background: rgba(8,16,36,.72); backdrop-filter: blur(6px); display: none; max-width: 86vw; }
  #caption b { font-size: 16px; font-weight: 600; }
  #caption span { display: block; margin-top: 3px; font-size: 12px; color: #9fb6e0; }
  #musicUI { position: fixed; left: 16px; bottom: 16px; z-index: 5; display: flex; gap: 10px;
    align-items: center; font-size: 13px; }
  #musicBtn { cursor: pointer; border: none; border-radius: 20px; padding: 8px 14px;
    background: rgba(80,140,255,.25); color: #dce8ff; backdrop-filter: blur(4px); }
  #musicBtn:hover { background: rgba(80,140,255,.45); }
  #musicName { color: #9fb6e0; max-width: 40vw; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  #empty { position: fixed; inset: 0; z-index: 6; display: none; align-items: center;
    justify-content: center; flex-direction: column; gap: 8px; text-align: center; padding: 24px; }
  #empty.show { display: flex; }
  #empty h2 { margin: 0; font-weight: 600; }
  #empty p { margin: 0; color: #9fb6e0; font-size: 14px; }
  #hint { position: fixed; right: 16px; bottom: 16px; z-index: 5; font-size: 12px;
    color: #6f86b3; text-align: right; line-height: 1.6; }
</style>
</head>
<body>
<canvas id="stars"></canvas>
<div id="stage"><div id="sphere"></div></div>
<div id="caption"></div>
<div id="musicUI">
  <button id="musicBtn">▶ 播放音乐</button>
  <span id="musicName">__MUSIC_NAME__</span>
</div>
<div id="hint">拖拽旋转视角 · 鼠标移到照片上放大<br>移开中央区域即回到球面</div>
<div id="empty"><h2>未找到照片</h2><p>请把图片放入源文件夹后，重新运行生成脚本。</p></div>
<audio id="audio" loop preload="auto"></audio>

<script>
const PHOTOS = __PHOTOS__;
const AUDIO  = "__AUDIO__";
const MUSIC_NAME = "__MUSIC_NAME__";
const SPIN   = __SPIN__;     // 自转角速度（弧度/帧）
const PREC   = __PREC__;     // 进动角速度（让两极漂移，避免照片长期停在顶/底）

const stage  = document.getElementById('stage');
const sphere = document.getElementById('sphere');
const caption= document.getElementById('caption');
const audio  = document.getElementById('audio');
const musicBtn = document.getElementById('musicBtn');
const musicName= document.getElementById('musicName');
const emptyEl = document.getElementById('empty');

if (!AUDIO) { document.getElementById('musicUI').style.display = 'none'; }
if (MUSIC_NAME) { musicName.textContent = MUSIC_NAME; }

// ---- 星空背景 ----
const sc = document.getElementById('stars');
const sctx = sc.getContext('2d');
let stars = [];
function initStars() {
  sc.width = innerWidth; sc.height = innerHeight;
  const n = Math.min(260, Math.floor(innerWidth * innerHeight / 7000));
  stars = Array.from({length: n}, () => ({
    x: Math.random()*innerWidth, y: Math.random()*innerHeight,
    r: Math.random()*1.4 + 0.3, a: Math.random(), s: Math.random()*0.02 + 0.004
  }));
}
function drawStars() {
  sctx.clearRect(0, 0, sc.width, sc.height);
  for (const st of stars) {
    st.a += st.s; const tw = 0.5 + 0.5*Math.sin(st.a);
    sctx.globalAlpha = 0.25 + tw*0.6;
    sctx.fillStyle = '#cfe0ff';
    sctx.beginPath(); sctx.arc(st.x, st.y, st.r, 0, 7); sctx.fill();
  }
  sctx.globalAlpha = 1;
}

// ---- 照片星球 ----
let W = innerWidth, H = innerHeight, cx = W/2, cy = H/2;
let BASE = 90, ACTIVE_SIZE = 320, R = 300, PERSP = 900;
let els = [];
let spinY = 0, spinZ = 0, tiltX = 0.15, intro = 0;
let active = -1, lockUntil = 0;
const HOVER_R = 64, RELEASE_FACTOR = 0.40;

function resize() {
  W = innerWidth; H = innerHeight; cx = W/2; cy = H/2;
  BASE = Math.max(64, Math.min(W, H) * 0.13);
  ACTIVE_SIZE = Math.min(W, H) * 0.40;
  R = Math.min(W, H) * 0.34;
  initStars();
}
window.addEventListener('resize', resize);

function rot(v, ay, ax, az) {
  let x = v.x, y = v.y, z = v.z, c, s;
  c = Math.cos(ay); s = Math.sin(ay);
  let x1 = x*c + z*s, z1 = -x*s + z*c, y1 = y;
  c = Math.cos(ax); s = Math.sin(ax);
  let y2 = y1*c - z1*s, z2 = y1*s + z1*c, x2 = x1;
  c = Math.cos(az); s = Math.sin(az);
  let x3 = x2*c - y2*s, y3 = x2*s + y2*c, z3 = z2;
  return {x: x3, y: y3, z: z3};
}
const lerp = (a, b, t) => a + (b - a) * t;
const map = (v, a, b, c, d) => c + (d - c) * ((v - a) / (b - a));

function init() {
  if (!PHOTOS.length) { emptyEl.classList.add('show'); return; }
  PHOTOS.forEach((p) => {
    const el = document.createElement('div');
    el.className = 'photo';
    const img = document.createElement('img');
    img.src = p.thumb; img.alt = p.name;
    img.addEventListener('error', () => el.classList.add('broken'));
    el.appendChild(img);
    sphere.appendChild(el);
    const sc2 = {x: (Math.random()*2-1), y: (Math.random()*2-1), z: (Math.random()*2-1)};
    const L = Math.hypot(sc2.x, sc2.y, sc2.z) || 1;
    els.push({
      el, img, base: {x: p.bx, y: p.by, z: p.bz}, name: p.name, date: p.date,
      scatter: {x: sc2.x/L*2.6, y: sc2.y/L*2.6, z: sc2.z/L*2.6},
      sx: cx, sy: cy, size: BASE, op: 0, gz: 0
    });
  });
  resize();
  stage.addEventListener('mousemove', onMove);
  stage.addEventListener('mouseleave', () => { active = -1; caption.style.display = 'none'; });
  // 拖拽旋转视角
  let dragging = false, lx = 0, ly = 0, userSpin = 0, userTilt = 0;
  stage.addEventListener('mousedown', e => { dragging = true; lx = e.clientX; ly = e.clientY; });
  window.addEventListener('mouseup', () => dragging = false);
  window.addEventListener('mousemove', e => {
    if (!dragging) return;
    userSpin += (e.clientX - lx) * 0.005; userTilt += (e.clientY - ly) * 0.005;
    userTilt = Math.max(-1.2, Math.min(1.2, userTilt));
    lx = e.clientX; ly = e.clientY;
  });
  stage._drag = () => ({userSpin, userTilt, dragging});
  setupAudio();
  requestAnimationFrame(loop);
}

function onMove(ev) {
  if (!els.length) return;
  const rect = stage.getBoundingClientRect();
  const mx = ev.clientX - rect.left, my = ev.clientY - rect.top;
  if (active >= 0) {
    if (Math.hypot(mx - cx, my - cy) > Math.min(W, H) * RELEASE_FACTOR) {
      active = -1; caption.style.display = 'none'; lockUntil = performance.now() + 500;
    }
    return;
  }
  if (performance.now() < lockUntil) return;
  let best = -1, bd = HOVER_R;
  for (let i = 0; i < els.length; i++) {
    const e = els[i];
    if (e.gz <= 0) continue;               // 只认朝前的照片
    const d = Math.hypot(mx - e.sx, my - e.sy);
    if (d < bd) { bd = d; best = i; }
  }
  if (best >= 0) {
    active = best;
    caption.innerHTML = '<b>' + escapeHtml(els[best].name) + '</b>' +
      (els[best].date ? '<span>' + els[best].date + '</span>' : '');
    caption.style.display = 'block';
  }
}
function escapeHtml(s){ return s.replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }

function loop(t) {
  drawStars();
  spinY += SPIN; spinZ += PREC;
  tiltX = 0.15 + 0.05 * Math.sin(t * 0.0004);
  intro = Math.min(1, intro + 0.012);
  const ease = 1 - Math.pow(1 - intro, 3);
  const drag = stage._drag ? stage._drag() : {userSpin: 0, userTilt: 0};
  const ay = spinY + drag.userSpin, ax = tiltX + drag.userTilt, az = spinZ;

  for (let i = 0; i < els.length; i++) {
    const e = els[i];
    const v = rot(e.base, ay, ax, az);
    const gx = lerp(e.scatter.x, v.x, ease);
    const gy = lerp(e.scatter.y, v.y, ease);
    const gz = lerp(e.scatter.z, v.z, ease);
    e.gz = gz;
    const f = PERSP / (PERSP - gz * R);
    const gx2 = cx + gx * R * f;
    const gy2 = cy - gy * R * f;
    const gsize = BASE * f;
    const gop = map(gz, -1.3, 1.3, 0.32, 1);

    if (active === i) {
      e.sx = lerp(e.sx, cx, 0.2);
      e.sy = lerp(e.sy, cy, 0.2);
      e.size = lerp(e.size, ACTIVE_SIZE, 0.2);
      e.op = lerp(e.op, 1, 0.2);
    } else {
      const k = active >= 0 ? 0.25 : 0.15;
      e.sx = lerp(e.sx, gx2, k);
      e.sy = lerp(e.sy, gy2, k);
      e.size = lerp(e.size, gsize, 0.15);
      e.op = lerp(e.op, active >= 0 ? 0.14 : gop, 0.15);
    }
    const h = e.size * (e.img.naturalHeight && e.img.naturalWidth
      ? e.img.naturalHeight / e.img.naturalWidth : 0.72);
    e.el.style.transform = 'translate(-50%,-50%) translate(' + e.sx + 'px,' + e.sy + 'px)';
    e.el.style.width = e.size + 'px';
    e.el.style.height = h + 'px';
    e.el.style.opacity = e.op.toFixed(3);
    e.el.style.zIndex = active === i ? 999 : String(Math.round((gz + 2) * 100));
    e.el.classList.toggle('active', active === i);
  }
  requestAnimationFrame(loop);
}

// ---- 背景音乐（内嵌，首次交互自动播放）----
let started = false;
function setupAudio() {
  if (!AUDIO) return;
  audio.src = AUDIO;
  const kick = () => {
    if (started) return;
    audio.play().then(() => { started = true; musicBtn.textContent = '⏸ 暂停音乐'; })
      .catch(() => {});
  };
  ['click', 'touchstart', 'keydown'].forEach(ev =>
    document.addEventListener(ev, kick, {once: true}));
  musicBtn.addEventListener('click', () => {
    if (audio.paused) { audio.play(); musicBtn.textContent = '⏸ 暂停音乐'; }
    else { audio.pause(); musicBtn.textContent = '▶ 播放音乐'; }
  });
}

init();
</script>
</body>
</html>
"""


# --------------------------------------------------------------------------
# 主流程
# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="生成交互式 3D 照片星球网页")
    ap.add_argument("src", help="源照片目录（递归扫描）")
    ap.add_argument("--out", default=None, help="输出目录，默认 <src>/星球相册")
    ap.add_argument("--music", default=None, help="要内嵌的音频文件（flac/mp3/...）")
    ap.add_argument("--title", default="照片星球", help="网页标题")
    ap.add_argument("--speed", type=float, default=1.0, help="自转速度倍率（默认 1.0）")
    ap.add_argument("--limit", type=int, default=0, help="只处理前 N 张（调试用）")
    ap.add_argument("--force", action="store_true", help="强制重新生成缩略图")
    ap.add_argument("--single", action="store_true",
                    help="把缩略图也 base64 内嵌，生成真正单文件 html（无需 thumbnails 文件夹，体积更大）")
    args = ap.parse_args()

    src = os.path.abspath(args.src)
    if not os.path.isdir(src):
        sys.exit(f"源目录不存在: {src}")
    out = os.path.abspath(args.out) if args.out else os.path.join(src, "星球相册")
    thumb_dir = os.path.join(out, "thumbnails")
    os.makedirs(thumb_dir, exist_ok=True)

    # 1) 扫描图片（跳过 thumbnails 目录与输出目录，避免把旧缩略图当照片重复收录）
    SKIP_DIRS = {"thumbnails"}
    out_real = os.path.realpath(out)
    files = []
    for root, dirs, fs in os.walk(src):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]   # 剪枝
        rr = os.path.realpath(root)
        if rr == out_real or rr.startswith(out_real + os.sep):
            continue
        for f in fs:
            if f.lower().endswith(EXT):
                files.append(os.path.join(root, f))
    files.sort()
    if args.limit:
        files = files[:args.limit]

    # 2) 缩略图 + 日期 + 尺寸
    records = []
    for i, path in enumerate(files):
        name = os.path.basename(path)
        tname = safe_name(name, i)
        tpath = os.path.join(thumb_dir, tname)
        make_thumb(path, tpath, force=args.force)
        w = h = 0
        try:
            with Image.open(tpath) as im:
                w, h = im.size
        except Exception:
            pass
        thumb_val = "thumbnails/" + tname
        if args.single:                      # 真·单文件：缩略图直接内嵌
            with open(tpath, "rb") as fh:
                thumb_val = "data:image/jpeg;base64," + base64.b64encode(fh.read()).decode("ascii")
        records.append({
            "name": name,
            "thumb": thumb_val,
            "date": get_capture_date(path) or "",
            "w": w, "h": h,
        })

    # 3) 球面分布 + 打乱（每次构建随机）
    n = len(records)
    pts = sphere_positions(n)
    order = list(range(n))
    random.seed()                      # 不固定种子 → 每次都不同
    random.shuffle(order)
    for rec, idx in zip(records, order):
        bx, by, bz = pts[idx]
        rec["bx"], rec["by"], rec["bz"] = round(bx, 5), round(by, 5), round(bz, 5)

    # 4) 音乐内嵌
    audio_uri = ""
    music_name = ""
    if args.music:
        mp = os.path.abspath(args.music)
        if not os.path.isfile(mp):
            sys.exit(f"音乐文件不存在: {mp}")
        ext = os.path.splitext(mp)[1].lower()
        mime = MIME.get(ext, "audio/mpeg")
        with open(mp, "rb") as fh:
            b64 = base64.b64encode(fh.read()).decode("ascii")
        audio_uri = f"data:{mime};base64,{b64}"
        music_name = os.path.basename(mp)
        print(f"已内嵌音乐: {music_name} ({len(b64)//1024} KB base64)")

    # 5) 渲染 HTML
    spin = round(0.008 * args.speed, 5)
    prec = 0.0015
    html = (TEMPLATE
            .replace("__TITLE__", args.title)
            .replace("__PHOTOS__", json.dumps(records, ensure_ascii=False))
            .replace("__AUDIO__", audio_uri)
            .replace("__MUSIC_NAME__", music_name)
            .replace("__SPIN__", str(spin))
            .replace("__PREC__", str(prec)))

    index_path = os.path.join(out, "index.html")
    with open(index_path, "w", encoding="utf-8") as fh:
        fh.write(html)

    print(f"完成 -> {index_path}")
    print(f"照片数: {n} | 缩略图: {thumb_dir} | 自转速度: {spin}/帧")
    if args.single and os.path.isdir(thumb_dir):
        shutil.rmtree(thumb_dir)
        print("已内嵌全部缩略图 → 真正单文件，无需 thumbnails 文件夹。")
    if not n:
        print("提示：未扫描到任何图片，网页会显示「未找到照片」。")


if __name__ == "__main__":
    main()
